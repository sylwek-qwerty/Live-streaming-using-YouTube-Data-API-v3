#!/bin/bash
# Ustaw zmienną TERM
export TERM=xterm



# Sprawdź, czy usługa jest uruchomiona
if ! systemctl is-active --quiet squirrelSRV.service; then
    echo "Usługa squirrelSRV.service nie jest uruchomiona. Uruchamiam..."
    # Zabijanie procesów ffmpeg
    sudo pkill -f "ffmpeg.*squirrelSRV.sh"
    sudo systemctl restart squirrelSRV.service
    # Poczekaj 10 sekund
    sleep 10
else
    echo "Usługa squirrelSRV.service już działa."
    sudo systemctl restart squirrelSRV.service
    sleep 10
fi

echo "KAMERA squirrel - uruchamiam strumień FFMPEG"

zmiennaA=""
zmiennaB=""
T1=$(date +%s)
no_frames_counter=0  # Licznik czasu braku klatek (w sekundach)

# Pętla główna
while true; do
    if [ -n "$TERM" ]; then
        tput reset
    fi

    # Sprawdzenie ilości klatek
    zmiennaA=$(tail -n 1 /mnt/ramdisk/FFMPEG_squirrel.log | sed -nr 's/.*size=\s*([0-9]+)kB.*/\1/p')

    echo "squirrel zmiennaA - $zmiennaA"
    echo "squirrel zmiennaB - $zmiennaB"
    T2=$(date +%s)
    diffsec="$(expr $T2 - $T1)"
    echo | awk -v D=$diffsec '{printf "Czas działania: %02d:%02d:%02d\n",D/(60*60),D%(60*60)/60,D%60}'

    # Sprawdzenie, czy zmienna się zmieniła
    if [ "$zmiennaA" = "$zmiennaB" ]; then
        if [ ! -z "$zmiennaA" ]; then
            printf "%s - Strumień squirrel zatrzymał się - restartowanie\n" "$(date)" >> /mnt/ramdisk/output_ffmpeg_squirrel.txt
            sudo systemctl restart squirrelSRV.service
        else
            echo "Czekam na pierwsze klatki wideo"
            sleep 15
            if [ -n "$TERM" ]; then
                tput reset
            fi
        fi
    fi

    # Jeżeli brak klatek przez 30 sekund, restartuj usługę
    if [ -z "$zmiennaA" ]; then
        ((no_frames_counter+=10))  # Liczymy czas, gdy klatki są puste
        echo "Brak klatek, liczenie czasu: $no_frames_counter sekund"
    else
        no_frames_counter=0  # Reset licznika, jeśli klatki pojawią się
    fi

    if [ "$no_frames_counter" -ge 30 ]; then
        echo "Brak klatek przez 30 sekund, restartuję usługę"
        printf "%s - Brak klatek przez 30 sekund - restartowanie usługi\n" "$(date)" >> /mnt/ramdisk/output_ffmpeg_squirrel.txt
        sudo systemctl restart squirrelSRV.service
        no_frames_counter=0  # Reset licznika po restarcie
    fi

    zmiennaB=$zmiennaA
    sleep 20
done
