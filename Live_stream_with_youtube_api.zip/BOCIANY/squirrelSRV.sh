#!/bin/bash
#plik="/home/polcraft/Pulpit/BOCIANY/FFMPEG_squirrel.log"
plik="/mnt/ramdisk/FFMPEG_squirrel.log"

rm -f "$plik"
touch "$plik"
chmod 777 "$plik"

STREAM_KEY=$(cat /home/polcraft/Pulpit/BOCIANY/klucz_squirrel.txt)

while true; do
        ffmpeg -rtsp_transport tcp -re -i "rtsp://bocianyonline.ddns.net:554/user=admin&password=polcraft2&channel=&stream=.sdp?real_stream--rtp-caching=500" \
-rtmp_live live -rtmp_buffer 3000 \
-c:v copy -b:v 3000k -c:a libmp3lame -ac 1 -b:a 128k -ar 44100 -strict 1 \
-f flv rtmp://a.rtmp.youtube.com/live2/$STREAM_KEY >> "$plik" 2>&1

    sleep 15
done
