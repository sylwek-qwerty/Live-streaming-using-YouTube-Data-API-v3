import os
import time
import google.auth
import pickle
import datetime
import paramiko
import subprocess
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.auth.transport.requests import Request


CLIENT_SECRETS_FILE = "/home/polcraft/Pulpit/python/client_secret_319016113701-2va1o2cjdjbk2lhoe1svnrtlgb2ct9p4.apps.googleusercontent.com.json########################"
API_NAME = 'youtube'
API_VERSION = 'v3'
SCOPES = ['https://www.googleapis.com/auth/youtube.force-ssl']

def get_authenticated_service():
    credentials = None
    token_path = "/home/polcraft/Pulpit/python/token_squirrel.pickle"

    if os.path.exists(token_path):
        with open(token_path, "rb") as token:
            credentials = pickle.load(token)

    if not credentials or not credentials.valid:
        if credentials and credentials.expired and credentials.refresh_token:
            try:
                credentials.refresh(Request())
            except google.auth.exceptions.RefreshError:
                print("Token wygasł lub został unieważniony. Usuwam plik token_squirrel.pickle i wykonuję ponowną autoryzację.")
                os.remove(token_path)  # Usuwamy nieaktualny token
                credentials = None  # Resetujemy dane uwierzytelniające
        if not credentials:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS_FILE, SCOPES)
            credentials = flow.run_local_server(port=0)

        with open(token_path, "wb") as token:
            pickle.dump(credentials, token)

    return build(API_NAME, API_VERSION, credentials=credentials)


def end_live_and_ready_broadcasts(youtube):
    try:
        broadcasts = youtube.liveBroadcasts().list(
            part="id,status",
            broadcastStatus="all",  # Wybieramy wszystkie statusy transmisji
            maxResults=50
        ).execute()

        if "items" in broadcasts and broadcasts["items"]:
            for broadcast in broadcasts["items"]:
                broadcast_id = broadcast["id"]
                current_status = broadcast["status"]["lifeCycleStatus"]

                if current_status == "complete":
                    continue

                print(f"Znaleziono transmisję: {broadcast_id}, status: {current_status}")

                # Sprawdzamy status i usuwamy transmisje o statusie ready, testing lub created
                if current_status in ["ready", "testing", "created"]:
                    try:
                        youtube.liveBroadcasts().delete(
                            id=broadcast_id
                        ).execute()
                        print(f"Transmisja {broadcast_id} została usunięta.")
                    except HttpError as e:
                        print(f"Błąd podczas usuwania transmisji {broadcast_id}: {e}")

                elif current_status == "live":
                    try:
                        youtube.liveBroadcasts().transition(
                            part="status",
                            broadcastStatus="complete",
                            id=broadcast_id
                        ).execute()
                        print(f"Transmisja {broadcast_id} została zakończona.")
                    except HttpError as e:
                        print(f"Błąd podczas kończenia transmisji {broadcast_id}: {e}")
        else:
            print("Brak transmisji do zakończenia lub usunięcia.")
    except HttpError as e:
        print(f"Błąd podczas pobierania transmisji: {e}")


def create_live_broadcast(youtube):
    try:
        start_time = datetime.datetime.now(datetime.timezone.utc).isoformat()
        broadcast = youtube.liveBroadcasts().insert(
            part='snippet,contentDetails,status',
            body={
                'snippet': {
                    'title': 'bociany-online.pl - Wiewiórka - LIVE',
                    'description': "Bociany Piórek i Lotka w Sławacinku Starym - Polska",
                    'tags': ["bociany", "sławacinek", "piórek", "lotka", "storks", "storchen", "StorkNest", "live"],
                    'scheduledStartTime': start_time
                },
                'contentDetails': {
                    'monitorStream': {
                        'enable': True
                    }
                },
                'status': {
                    'privacyStatus': 'public',
                    'ageRestricted': False
                }
            }
        ).execute()

        print(f"Transmisja zosta³a utworzona: {broadcast['id']}")
        return broadcast
    except HttpError as e:
        print(f"B³¹d podczas tworzenia transmisji: {e}")
        return None


def create_live_stream(youtube):
    try:
        stream = youtube.liveStreams().insert(
            part='snippet,cdn',
            body={
                'snippet': {
                    'title': 'bociany-online.pl - Wiewiórka - LIVE'
                },
                'cdn': {
                    'format': '1080p',
                    'ingestionType': 'rtmp',
                    'resolution': '1080p',
                    'frameRate': '30fps'
                }
            }
        ).execute()
        print(f"Strumień został utworzony: {stream['id']}")
        return stream
    except HttpError as e:
        print(f"Błąd podczas tworzenia strumienia: {e}")
        return None

def bind_broadcast_to_stream(youtube, broadcast_id, stream_id):
    try:
        youtube.liveBroadcasts().bind(
            part='id,contentDetails',
            id=broadcast_id,
            streamId=stream_id
        ).execute()
        print(f"Transmisję {broadcast_id} połączono ze strumieniem {stream_id}")
    except HttpError as e:
        print(f"Błąd podczas łączenia transmisji ze strumieniem: {e}")

def is_stream_active(youtube, stream_id):
    try:
        stream = youtube.liveStreams().list(
            part='status',
            id=stream_id
        ).execute()

        stream_status = stream['items'][0]['status']['streamStatus']
        print(f"Status strumienia: {stream_status}")
        return stream_status == 'active'
    except HttpError as e:
        print(f"Błąd podczas sprawdzania statusu strumienia: {e}")
        return False

def transition_to_testing(youtube, broadcast_id):
    try:
        youtube.liveBroadcasts().transition(
            part="status",
            broadcastStatus="testing",
            id=broadcast_id
        ).execute()
        print("Transmisja przeszła do etapu 'testing'.")
    except HttpError as e:
        print(f"Błąd podczas przejścia do 'testing': {e}")

def transition_to_live(youtube, broadcast_id):
    try:
        youtube.liveBroadcasts().transition(
            part="status",
            broadcastStatus="live",
            id=broadcast_id
        ).execute()
        print("Transmisja jest teraz LIVE!")
        print("")
        print("Możesz zamknąć okno terminala")
    except HttpError as e:
        print(f"Błąd podczas przejścia do 'live': {e}")

def start_live_stream():


    youtube = get_authenticated_service()

    # Zakończ transmisje 'live' i usuń transmisje 'ready'
    end_live_and_ready_broadcasts(youtube)

    broadcast = create_live_broadcast(youtube)
    if not broadcast:
        print("Błąd podczas tworzenia transmisji.")
        return

    stream = create_live_stream(youtube)
    if not stream:
        print("Błąd podczas tworzenia strumienia.")
        return

    stream_key = stream['cdn']['ingestionInfo']['streamName']
    print(f"Klucz strumienia: {stream_key}")

    with open("/home/polcraft/Pulpit/BOCIANY/klucz_squirrel.txt", "w") as f:
        f.write(stream_key)

    broadcast_url = f"https://www.youtube.com/watch?v={broadcast['id']}"
    print(f"URL transmisji: {broadcast_url}")

    bind_broadcast_to_stream(youtube, broadcast['id'], stream['id'])

    with open('current_video_id_squirrel.txt', 'w') as f:
        f.write(broadcast['id'])

    hostname = "ip_www_server#############"
    port = 22
    username = "ssh_user############"
    password = "ssh_password###########"
    remote_path = "/var/www/bociany-online.pl/current_video_id_squirrel.txt##################"
    local_path = "current_video_id_squirrel.txt"

    try:
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname, port=port, username=username, password=password)

        sftp = ssh_client.open_sftp()
        sftp.put(local_path, remote_path)
        print(f"Plik '{local_path}' przesłano na serwer '{hostname}' do '{remote_path}'.")
        sftp.close()

    except Exception as e:
        print(f"Błąd podczas połączenia lub przesyłania pliku: {e}")
    finally:
        ssh_client.close()


    # Sprawdź i zatrzymaj istniejące instancje SQUIRREL.sh
    print("Sprawdzanie i zamykanie istniejących instancji SQUIRREL.sh...")
    try:
        output = subprocess.check_output(["pgrep", "-f", "SQUIRREL.sh"])
        pids = output.decode().strip().split('\n')
        for pid in pids:
            print(f"Zatrzymuję proces SQUIRREL.sh o PID: {pid}")
            os.system(f"kill -9 {pid}")
    except subprocess.CalledProcessError:
        print("Brak uruchomionych instancji SQUIRREL.sh.")
    print("Uruchamiam skrypt SQUIRREL.sh...")
    #SQUIRREL.sh uruchomiony jest jako usługa squirrel.service
    #os.system("nohup bash /home/polcraft/Pulpit/BOCIANY/SQUIRREL.sh > /home/polcraft/Pulpit/BOCIANY/squirrel.log 2>&1 &")
    time.sleep(20)
    for _ in range(3):
        if is_stream_active(youtube, stream['id']):
            transition_to_testing(youtube, broadcast['id'])
            time.sleep(20)
            transition_to_live(youtube, broadcast['id'])
            break
        else:
            print("Strumień nieaktywny. Próba ponownego uruchomienia.")
            # Zamkniêcie wszystkich istniej¹cych instancji SQUIRREL.sh
            os.system("pkill -f SQUIRREL.sh")

            # Uruchomienie nowej instancji SQUIRREL.sh w tle
            #SQUIRREL.sh uruchomiony jest jako usługa squirrel.service
            #os.system("nohup bash /home/polcraft/Pulpit/BOCIANY/SQUIRREL.sh > /home/polcraft/Pulpit/BOCIANY/squirrel.log 2>&1 &")


            time.sleep(20)

start_live_stream()
